﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CorpTrayLauncher
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            RightClickContextMenuStrip.Show(Cursor.Position);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (System.Diagnostics.Debugger.IsAttached == false)
            {
                this.Hide();
            }
            else
            {
                this.Text = "This is normally hidden UNLESS being debugged";
            }

            notifyIcon1.Visible = true;
            notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.MouseClick += notifyIcon1_MouseDoubleClick;
            notifyIcon1.ContextMenuStrip = this.RightClickContextMenuStrip;

            // grab all the groups stored in the reg that ARE active
            var Groups = RegSettingChecker.GetGroups(null);
            for (int i = 0; i < Groups.Count; i++)
            {
                var group = Groups[i];
                if (group.IsEnabled)
                {
                    RightClickContextMenuStrip.AddGroup(Groups[i]);
                }
            }
        }
    }
}
