#include "common.h"
#include "tool_functions.h"
bool SILENCE = false;

/*
* Noteice most of the tool functions are moved to be defined in individual source files such as killprocess, osver and recylcinbin
*/