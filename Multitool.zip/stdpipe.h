#pragma once
#include <windows.h>
extern void SETUP_PIPES();

extern HANDLE STDIN;
extern HANDLE STDOUT;
extern HANDLE STDERR;